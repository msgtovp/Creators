window.addEventListener("load", loadActions);
function clearShowing() {
	var sel = document.getElementsByClassName('error-info');
	for(var itr = 0; itr < sel.length; itr++) {
		sel[itr].style = "display:none";
	}
}
function showForm(selector) {
	clearShowing();
	document.getElementById(selector).style = "display:block";
}

function loadActions() {
	var ops = document.getElementsByName('operations');
	for(var itr = 0; itr < ops.length; itr++) {
		ops[itr].addEventListener("click",function(){
			showForm(this.getAttribute('data-target'));
		});
	}
}
