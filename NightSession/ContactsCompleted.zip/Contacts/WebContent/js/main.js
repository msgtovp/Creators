function loadDatasFromDB() {
	var xhr = new XMLHttpRequest();
	xhr.open("get","view");
	xhr.send();
	xhr.onreadystatechange = function(){
		if(this.readyState === 4) {
			document.getElementById('content-change').innerHTML = this.responseText;
		}
	};
}
function addClickEvent() {
	var sels = document.getElementsByClassName("menu-item");
	for(var i = 0; i < sels.length; i++) {
		sels[i].addEventListener("click",function(){
			var loc = this.getAttribute("data-target");
			var xhr = new XMLHttpRequest();
			xhr.open("get",loc);
			xhr.send();
			xhr.onreadystatechange = function(){
				if(this.readyState === 4) {
					document.getElementById('content-change').innerHTML = this.responseText;
				}
			};
		});
	}
}
window.addEventListener("load", addClickEvent);
window.addEventListener("load", loadDatasFromDB);








