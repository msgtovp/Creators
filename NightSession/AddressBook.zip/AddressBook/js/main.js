window.addEventListener("load", addButtonAction);
window.addEventListener("load", addSelectionAction);

function addSelectionAction() {
	var games = document.getElementsByName('games');
	for(var itr = 0; itr < games.length; itr++) {
		games[itr].addEventListener("click", function(){
			alert(this.checked);
		});
	}
}

function addButtonAction() {
	var btn = document.getElementById('btnSubmit');
	btn.addEventListener("click", saveInDB);
}
function saveInDB() {
	// Do Validate here
	// AJAX Request Here
}