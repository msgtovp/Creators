public class Authentication extends Login {
	public boolean proceed(String username, String password) {
		if(username.equals("user")&&password.equals("secret"))
			return true;
		return false;
	}
}