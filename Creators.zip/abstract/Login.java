abstract public class Login {
	abstract public boolean proceed(String username, String password);
	public void sayHello() {
		
	}
}