public class Solution {
	public static void main(String cmds[]) {
		Login lgn = new Authentication();
		if(lgn.proceed("user", "secret")) {
			System.out.println("Success");
		} else {
			System.out.println("Failure");
		}
	}
}