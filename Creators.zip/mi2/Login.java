public interface Login {
	public boolean proceed(String username, String password);
}