public interface Profile extends Login {
	public boolean get(String username);
}