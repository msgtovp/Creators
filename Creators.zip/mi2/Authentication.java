public class Authentication implements Profile {
	public boolean get(String username) {
		return false;
	}
}