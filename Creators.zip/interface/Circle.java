public interface Circle {
	public int val = 5;
	public void area();
}