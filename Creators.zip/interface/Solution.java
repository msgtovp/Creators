public class Solution {
	public static void main(String args[]) {
		Circle cir = new Shape();
		cir.val = 7;
	}
}