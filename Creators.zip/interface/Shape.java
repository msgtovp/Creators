public class Shape implements Circle {
	public int val;
	public void area() {

	}
}