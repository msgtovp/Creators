abstract public class Profile extends Login {
	abstract public boolean get(String username);
}