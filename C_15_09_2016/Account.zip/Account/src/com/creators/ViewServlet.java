package com.creators;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.creators.java.Database;
import com.creators.java.UserTbl;
import com.google.gson.Gson;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/render")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out = response.getWriter()) {
			response.setContentType("application/json");
			PreparedStatement ps = Database.getStmt("select * from user_tbl");
			try {
				ResultSet rs = ps.executeQuery();
				List<UserTbl> li = new LinkedList<UserTbl>();
				while(rs.next()) {
					li.add(new UserTbl(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
				out.println(new Gson().toJson(li));
				out.flush();
				out.close();
			} catch (Exception e) {}
		}
	}

}



















