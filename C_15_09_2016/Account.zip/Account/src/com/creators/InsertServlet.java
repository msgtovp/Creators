package com.creators;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.TreeMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.creators.java.Database;
import com.google.gson.Gson;

/**
 * Servlet implementation class InsertServlet
 */
@WebServlet("/insert")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out = response.getWriter()) {
			response.setContentType("application/json");
			Map<String, String> li = null;
			try {
				String user = request.getParameter("username");
				String pass = request.getParameter("password");
				String first = request.getParameter("firstName");
				String last = request.getParameter("lastName");
				PreparedStatement ps = Database.getStmt("select * from user_tbl where username = ?");
				ps.setString(1, user);
				ResultSet rs = ps.executeQuery();
				li = new TreeMap<String, String>();
				if(rs.next()) {
					li.put("code", "0");
					li.put("message", "Username Exist");
				} else {
					ps = Database.getStmt("insert into user_tbl values(?,?,?,?)");
					ps.setString(1, user);
					ps.setString(2, pass);
					ps.setString(3, first);
					ps.setString(4, last);
					ps.executeUpdate();
					li.put("code", "1");
					li.put("message", "Successfully Inserted");
				}
				out.println(new Gson().toJson(li));
				out.flush();
				out.close();
			} catch (Exception e) {
				li.put("code", "0");
				li.put("message", e.toString());
				out.println(new Gson().toJson(li));
			}
		}
	}

}
