var renderDatas = {};
var renderHTML = {
		"error": "<div id='error-message'></div>",
		"insert":{
			"actionurl": "insert",
			"controls": [
			           {
			        	   "type": "text", "placeholder": "Username", "id": "username"
			           },
			           {
			        	   "type": "password", "placeholder": "Password", "id": "password"
			           },
			           {
			        	   "type": "text", "placeholder": "First Name", "id": "firstName"
			           },
			           {
			        	   "type": "text", "placeholder": "Last Name", "id": "lastName"
			           }
			],
			"buttonText": "Insert", 
			"action": function() {
				var user = document.getElementById('username').value;
				var pass = document.getElementById('password').value;
				var first = document.getElementById('firstName').value;
				var last = document.getElementById('lastName').value;
				// Do Javascript Regex Here
				AJAXRequest("insert",checkUser, "username="+user+"&password="+pass+"&firstName="+first+"&lastName="+last);
			}			
		},
		"update":{
			"actionurl": "update",
			"buttonText": "Update", 
			"action": function() {
				var user = document.getElementById('username').value;
				var pass = document.getElementById('password').value;
				var first = document.getElementById('firstName').value;
				var last = document.getElementById('lastName').value;
				// Do Javascript Regex Here
				AJAXRequest("update",checkUser, "username="+user+"&password="+pass+"&firstName="+first+"&lastName="+last);
			}			
		}
};

function checkUser(datas){
	if(datas.code === '1') {
		AJAXRequest("render",renderUser);
		console.log(datas.message);
	} else {
		document.getElementById('error-message').innerText = datas.message;
	}
}

function AJAXRequest(url, func, args) {
	if(args === undefined) args= "";
	var xhr = new XMLHttpRequest();
	xhr.open("POST",url, true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send(args);
	xhr.onreadystatechange = function() {
		if(this.readyState == 4 && this.status == 200) {
			func(JSON.parse(this.responseText));
		}
	};
}
function loadUsers() {
	AJAXRequest("render",renderUser);
}
function renderUser(datas) {
	renderDatas =datas;
	var elem = document.getElementById("content-holder");
	var tab = "<table>\n";
	tab += "<tr><th>Username</th><th>Password</th><th>Firstname</th><th>Lastname</th><th>Edit</th><th>Delete</th></tr>\n";
	for(var i = 0; i < datas.length; i++) {
		tab += '<tr><td>'+datas[i].username+'</td><td>'+datas[i].password+'</td><td>'+datas[i].firstName+'</td><td>'+datas[i].lastName+'</td><td><a class="edit-icon" data-target="'+i+'" href="#"></a></td><td><a class="delete-icon" data-target="'+datas[i].username+'" href="#"></a></td></tr>\n';
	}
	tab += "</table>\n";
	tab += renderHTML["error"];
	elem.innerHTML = tab;
	var editColl = document.getElementsByClassName("edit-icon");
	for(var i = 0; i < editColl.length; i++) {
		editColl[i].addEventListener("click", function() {
			var id = parseInt(this.getAttribute("data-target"));
			var idxv = ["username","password","firstName","lastName"];
			var repl = document.getElementById('content-holder');
			var tag = "<div id='form-holder'>\n";
			var ctrls = renderHTML["insert"]["controls"];
			for(var i = 0; i < ctrls.length; i++) {
				if(i === 0)
					tag += '<input type="hidden" value="'+renderDatas[id][idxv[i]]+'" id="'+ctrls[i]["id"]+'" />\n';
				else
					tag += '<input type="'+ctrls[i]["type"]+'" value="'+renderDatas[id][idxv[i]]+'" id="'+ctrls[i]["id"]+'" />\n';
			}
			tag += '<input type="button" id="btn'+renderHTML["update"]["actionurl"]+'" value="'+renderHTML["update"]["buttonText"]+'" data-click="'+renderHTML["update"]["actionurl"]+'" />\n';
			tag += renderHTML["error"]+'\n';
			tag += '</div>\n';
			repl.innerHTML = tag;
			document.getElementById("btn"+renderHTML["update"]["actionurl"]).addEventListener("click", renderHTML["update"]["action"]);
		});
	}
	editColl = document.getElementsByClassName("delete-icon");
	for(var i = 0; i < editColl.length; i++) {
		editColl[i].addEventListener("click", function() {
			AJAXRequest("delete",checkUser, "username="+this.getAttribute("data-target"));
		});
	}
}
window.addEventListener("load", loadUsers);
window.addEventListener("load", function() {
	var elem = document.getElementById('add-btn');
	elem.addEventListener('click', function(){
		var repl = document.getElementById('content-holder');
		var tag = "<div id='form-holder'>\n";
		var ctrls = renderHTML["insert"]["controls"];
		for(var i = 0; i < ctrls.length; i++) {
			tag += '<input type="'+ctrls[i]["type"]+'" placeholder="'+ctrls[i]["placeholder"]+'" id="'+ctrls[i]["id"]+'" />\n';
		}
		tag += '<input type="button" id="btn'+renderHTML["insert"]["actionurl"]+'" value="'+renderHTML["insert"]["buttonText"]+'" data-click="'+renderHTML["insert"]["actionurl"]+'" />\n';
		tag += renderHTML["error"]+'\n';
		tag += '</div>\n';
		repl.innerHTML = tag;
		document.getElementById("btn"+renderHTML["insert"]["actionurl"]).addEventListener("click", renderHTML["insert"]["action"]);
	});
});